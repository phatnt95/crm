export class Contact {
}
